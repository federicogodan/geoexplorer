var geocoding_data = [
    ['Africa', '-17,-35,51,37'],
    ['Fouta Djallon Highlands', '-16,3,3,17'],
    ['Côte d\'Ivoire', '-9,4,-2,11'],    
    ['Gambia', '-17,13,-13,14'],
    ['Guinea', '-15,7,-7,13'],
    ['Guinea-Bissau', '-17,11,-13,13'],
    ['Mali', '-13,10,-5,25'],
    ['Sierra Leone', '-14,7,-10,10'],
    ['Senegal', '-18,12,-11,17']
];